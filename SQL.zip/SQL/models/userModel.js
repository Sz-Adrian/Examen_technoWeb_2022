class User {
    constructor(aname, qty){
        this.aname = aname;
        this.qty = qty;
    }
}

module.exports = User;